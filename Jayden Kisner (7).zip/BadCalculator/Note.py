import random as rd

def update_count(key):
    successErrorCount[key] += 1
    return

operators = ['-','+','*','/']
successErrorCount = {"Success": 0, "Error": 0}
running = True

while running:
    answer = input("please enter a number so I can change it: ")
    try:
        userNumber = int(answer)
        newNumber = userNumber * rd.randint(1,1000)
        print(f"Your new number is: {newNumber}")
        update_count("Success")
    except Exception as e:
        print(f"You did something wrong!!")
        print(f"Your exceptions says: {e}")
        update_count("Error")
    again = input("Would you like to try again? (Y/N) : ")
    if again.upper() == ("N"):
        print(f"Thank for using this app! Your Success count was {successErrorCount.get('Success')} and your error count was {successErrorCount.get('Error')}")
        print("Goodbye")
        running = False