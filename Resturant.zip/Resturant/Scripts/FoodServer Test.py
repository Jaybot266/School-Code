#Jayden Kisner
#10/31/22
#This is a test for Foodserver program

import random as rd

class table():
    def __init__(self, food, drink):
        self.food = food
        self.drink = drink

    def request(self):
        print(f'I would like {self.food} to eat and a {self.drink} to drink please.')

    def order(self):
        oInfo = f"They ordered {self.food}, and {self.drink}"
        return oInfo




Request = []
Foods = ['Sirloen steak', 'French Fries', 'Mac and Cheese', 'Cheeseburger']
Drinks = ['Water', 'Coke a cola', 'Root Beer', 'Mr.Pibb', 'Sprite', 'Dr.Pepper']

for i in range(5):
    order = table(rd.choice(Foods), rd.choice(Drinks))
    table.request()

print(order)