#Jayden Kisner
#9/20/22
#Secret Message Test

running = True
def nodupes(string):
    newstring = ''
    for i in string:
        if i not in newstring:
            newstring += i
    return newstring


def buildcypherdict(CypherString,PlainString):
    cypherdict =  {}
    clen = len(CypherString)
    for i in range(0, clen -1):
        cypherdict[PlainString[i]] = CypherString[i]
    return cypherdict


def buildDecypherdict(PlainString,CypherString):
    Decypherdict =  {}
    clen = len(CypherString)
    for i in range(0, clen -1):
        Decypherdict[CypherString[i]] = PlainString[i]
    return Decypherdict


def changemsg(message,dictonary):
    newmsg = ''
    for i in range(0, len(message)):
        value = dictonary.get(message[i], "Empty")
        if value == "Empty":
            newmsg += message[i]
        else:
            newmsg += value
    return newmsg


keyword = input("Enter a key that is atleast 3 letters long:")
while (len(keyword) < 3):
    keyword = input("That didn't seem to work")
    keyword = nodupes(keyword)


PlainString = ('abcdefghijklmnopqrstuvwxyzABCEDFGHIJKLMNOPQRSTUVWXYZ')
CypherString = (nodupes(keyword +'zyxwvutsrqponmlkjihgfedcbaZYXWVUTSRQPONMLKJIHGFEDCBA'))

UsetoEncrypt = buildcypherdict(CypherString, PlainString)
UsetoDecrypt = buildDecypherdict(PlainString,CypherString)
useCho = input("Encrypt or Decrypt \n")

while running:
    if (useCho.upper() == "ENCRYPT"):
        useMessage = input("What is your message?: ")
        useMessage = changemsg(useMessage, UsetoEncrypt)
        print(useMessage)
        running = False
    else:
        if  (useCho.upper() == "DECRYPT"):
            useMessage = input("What would you like to Decrypt: ")
            useMessage = changemsg(useMessage, UsetoDecrypt)
            print(useMessage)
            running = False
        else:
            if useCho != 'ENCRYPT' or 'DECRYPT':
                print("That was not a valid answer again: \n")
                useCho = input("Encrypt or Decrypt \n")
goodbye = input(":")