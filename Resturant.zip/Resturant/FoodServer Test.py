#Jayden Kisner
#10/31/22
#This is a test for Foodserver program

import random as rd

class waiter():
    def __init__(self, tables):
        self.table = tables

    def work(self):
        self.tables = rd.randint(1,10)
        return self.tables
        print(f"I have to wait {tables} tables today")



class Table():
    def __init__(self, food, drink):
        self.food = food
        self.drink = drink

    def request(self):
        print(f"I would like {self.food} to eat and a {self.drink} to drink please.")

    def order(self):
        oInfo = f"At table {tableNum}, they ordered {self.food}, and {self.drink}"
        return oInfo

Request = []
tableNum = 0
Foods = ['Sirloen steak', 'French Fries', 'Mac and Cheese', 'Cheeseburger', 'potato soup', 'NY strip', 'Ribeye',
         'Fried Chicken', 'Brocali', 'Filet mignon', 'Ceaser Salad', 'Lobster', 'Ribs', 'Glazed chicken',
         'A T-Bone steak', 'Rolls']
Drinks = ['Water', 'Coke a cola', 'Root Beer', 'Mr.Pibb', 'Sprite', 'Dr.Pepper', 'Sweet Tea', 'UnSweet Tea', 'Coffee',
          'Diet Coke a cola', 'Milk', 'Apple juice', 'Beer']

print("It's time for me to start work.")
for i in range(waiter.work()):
    tableNum += 1
    tabreq = rd.randint(1, 5)
    for i in range(tabreq):
        order = Table(rd.choice(Foods), rd.choice(Drinks))
        print("Yes")
        Table.request()
        Request.append(Table.order())
    if tableNum == waiter.work():
        break

print(Request)
print("That's all the tables, I'm heading home.")
