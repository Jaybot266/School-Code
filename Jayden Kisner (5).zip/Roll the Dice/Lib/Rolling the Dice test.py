#Jayden Kisner
#9/6/22
#Roll the Dice = Test for main
import random as rd
myDict={"Win": 0, "Lose": 0}
numRoll={1: 0, 2: 0, 3: 0, 4: 0, 5: 0, 6: 0}
running = True
print(myDict)
print(numRoll)
while running:
    perCho = input("Do you want to play?: ")
    if perCho == "y":
        comNum = rd.randint(1,6)
        myNum = rd.randint(1,6)
        print(comNum, myNum)
        if comNum < myNum:
            print("Win")
            myDict["Win"]+=1
            print(myDict)
            print(numRoll)
        else:
            if comNum > myNum:
                print("Lose")
                myDict["Lose"] += 1
                print(myDict)
            else:
                if comNum == myNum:
                    print("Tie")
    else:
        if perCho == "n":
            running = False
print("Goodbye")