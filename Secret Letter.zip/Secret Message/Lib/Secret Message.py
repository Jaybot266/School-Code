#Jayden Kisner
#9/21/22
#Secret Message = Encrypting a message from the user and then being abla to decrypt the message if they are using the same key
