#Jayden Kisner
#8/29/22
#Guess the Number - Guessing the number the computer generated
#My Final version of this assignment

import random as rd

print("Hey friend how have you been?")
perName = input("Hey sorry to ask, but whats your name?: ").capitalize()
print(f"{perName}, ah yes thank you for reminding me.")
chIce = input("Hey I can up with a new game to play. Would you like to play it?: ").upper()
if chIce == "YES":
    print("Let's play!")
else:
    if chIce == "NO":
        print("Well to bad you open me up, so we are going to play. If you're okay with it.")
    else:
        print("I can't understand you, so I am going to assume you said yes.")
tries = 0
comNum = rd.randint(1, 20)
running = True
print("The name of the game is that I come up with a number, and you have to try to guess it.")
print("I'm going to generate the number now")
print('...')
print("I've came up with a number. I will tell you that my number is between 1 and 20")
while running:
    tries += 1
    if tries < 4:
        guess = input("Try to guess my number: ")
        if guess.isalpha():
            print("Can you please type a number. By the way you wasted an attempt.")
        else:
            perNum = int(guess)
            if perNum == comNum:
                print("You did, you guessed my number")
                running = False
            else:
                if perNum > comNum:
                    print("sorry too tell you this, but your answer was wrong. Try to go lower.")
                else:
                    print("Sorry to tell you this but your number is wrong, it was too low. Try to go higher.")
    else:
        print(f"Sorry to say this but you lost the game. I will let you know that my number was {comNum}")
        running = False
print("That was a fun Game :)")
print(f"I hope that we can play again. Goodbye {perName}.")
#You can say Goodbye to the computer so , be nice please. I also added this so, it would run outside pycharm.
Goodbye = input(":")