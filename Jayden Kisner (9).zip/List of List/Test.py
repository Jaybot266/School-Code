#Jayden Kisner
#9/27/22
#List of List Test
import random as rd

InList = ["Pasta", "Strawberrys", "Avacados", "Ground Beef", "Oranges", "Pepper", "Salt", "Pork", "Bread", "Lettece", "Ginger", "Basil", "apples", "Eggs", "Carrots", "Butter", "Potatos", "Bacon", "Tomatos", "Paprika", "Squids", "Crabs", "Onions", "Chocolate", "Spagethei sauce", "oysters", "Milk", "Pears", "Fish", "Dill", "Spinage", "Chicken", "Chips", "Shrimp"]

Shopping = True

Days = 0

TotalItems = []

while Shopping:
    try:
        Test = int(input("How many time do you want to go shopping?: "))
        Shopping = False
    except:
        print("Please enter a number")
    for i in range(Test):
        Days += 1
        ItemsGot = []
        for i in range(5):
            Steve = rd.choice(InList)
            ItemsGot.append(Steve)
            TotalItems.append(Steve)
        print(f"On day {Days} she got {ItemsGot}")
        print(" ")
print(f"In total she got {TotalItems}, after {Days} Days.")