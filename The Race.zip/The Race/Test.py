#Jayden Kisner
#4/27/23
#Race Game - A game to race the computer
import PySimpleGUI as pg
import random as rd


Cards = ["1", "2", "3", "4", "5", "To the beginning", "-1", "-2", "-3", "-4", "-5", "10", "20","Double"]

#class position(pCards):
    #pPosition = 0
    #if pCards == "1":
        #pPosition += 1
    #if pCards == "2":
     #   pPosition += 2
    #if pCards == "3":
   #     pPosition += 3
  #  if pCards == "4":
   #     pPosition += 4
   # if pCards == "5":
   #     pPosition += 5
  #  if pCards == "1":
   #     pPosition == 0


pPosition = 0
cPosition = 0
rounds = 0
running = True
Test = False

layout = [[pg.Text("Race Game", enable_events = True,key = '-text-')],
        [pg.MLine(size =(60,15), key ='-Response-', reroute_stdout = True, auto_refresh = True, disabled = True, do_not_clear = True)],
        [ pg.Button('Chose a card', key= '-Submit-',bind_return_key = True),pg.Text("                                                        "),
            pg.Button('Restart', key= '-Again-',bind_return_key = True), pg.Button('End', key= '-End-',bind_return_key = True)],
        [pg.Text("Player:"), pg.Text(" "), pg.ProgressBar(100,size = (30, 10),bar_color = ('green', 'grey'), key='-Bar-')],
        [pg.Text("Computer:"),pg.ProgressBar(100,size = (30, 10),bar_color = ('red', 'grey'), key='-Bar2-')]]

window = pg.Window("Race Game", layout,finalize = True)

while running:
    event, values = window.read()
    if event == pg.WINDOW_CLOSED or event == 'Quit':
        break
    if rounds == 0:
        window['-Response-'].update('', append=False)
        print("Hello")
    if event == '-Submit-':
        pCards = rd.choice(Cards)
        cCards = rd.choice(Cards)
        window['-Response-'].update('', append=False)
        print(f"You pulled a {pCards} Card, and the computer pulled a {cCards} card")
        #Player
        if pCards == "1":
            pPosition += 1
        if pCards == "2":
           pPosition += 2
        if pCards == "3":
            pPosition += 3
        if pCards == "4":
            pPosition += 4
        if pCards == "5":
            pPosition += 5
        if pCards == "To the beginning":
             pPosition = 0
        if pCards == "-1":
            pPosition -= 1
        if pCards == "-2":
           pPosition -= 2
        if pCards == "-3":
            pPosition -= 3
        if pCards == "-4":
            pPosition -= 4
        if pCards == "-5":
            pPosition -= 5
        if pCards == "10":
            pPosition += 10
        if pCards == "20":
            pPosition += 20
        if pCards == "Double":
            pPosition *= 2
        if pPosition < 0:
            pPosition = 0

        #Computer
        if cCards == "1":
            cPosition += 1
        if cCards == "2":
           cPosition += 2
        if cCards == "3":
            cPosition += 3
        if cCards == "4":
            cPosition += 4
        if cCards == "5":
            cPosition += 5
        if cCards == "To the beginning":
             cPosition = 0
        if cCards == "-1":
            cPosition -= 1
        if cCards == "-2":
           cPosition -= 2
        if cCards == "-3":
            cPosition -= 3
        if cCards == "-4":
            cPosition -= 4
        if cCards == "-5":
            cPosition -= 5
        if cCards == "10":
            cPosition += 10
        if cCards == "20":
            cPosition += 20
        if cCards == "Double":
            cPosition *= 2
        if cPosition < 0:
            cPosition = 0

        window['-Bar-'].update(pPosition)
        window['-Bar2-'].update(cPosition)
        print(f"Your current postion is: {pPosition}")
        print(f"The Computer's postion is: {cPosition}")
        if pPosition >= 100:
            print ("Win")
        if cPosition >= 100:
            print("Lose")
        rounds += 1
    if event == '-Again-':
        pPosition = 0
        cPosition = 0
        window['-Response-'].update('', append=False)
        window['-Bar-'].update(pPosition)
        window['-Bar2-'].update(cPosition)
        print("You have restarted")

    if event == '-End-':
        break
