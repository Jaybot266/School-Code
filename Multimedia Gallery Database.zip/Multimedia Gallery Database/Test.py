from tkinter import *
from PIL import ImageTk,Image

root = Tk()

e = Entry(root)
e.grid(row=20,column=9)
e.insert(0, "Enter your name")


def myClick():
    myLabel3 = Label(root, text="Hi "+e.get())
    myLabel3.grid(row=10,column=5)

#creating a label widget
myLabel1 = Label(root, text="Hello world!")
myLabel2 = Label(root, text="Hello there!")
myButton = Button(root, text="Hi", padx=50, pady=50, command=myClick, fg="blue", bg="black")
Bye = Button(root, text="Bye", command=root.quit)
frame = LabelFrame(root, text="This is a frame", padx=5, pady=5)
b = Button(frame, text="Gay")

#Shoving onto screen
myLabel1.grid(row=0, column=0)
myButton.grid(row=3, column=3)
myLabel2.grid(row=1, column=5)
Bye.grid(row=8, column=3)
frame.grid(row=9, column=2)
b.grid(row=9, column=2)




root.mainloop()
