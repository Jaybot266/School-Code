import random as rd
print("Hello friend!")
print("Hey I'm trying to get the same pair of socks, but I have to many socks.")
colors = ["red", "green", "blue", "indego", "violet", "orange", "yellow", "pink", "white", "black", "brown", "Gray", "Teal", "Lime"]
shapes = ["squares", "circles", "rectangle", "pyramid", "triangle", "rhombus", "star", "heart", "fish", "rings", "Oval", "Pentagon", "Octagon"]
print("I'm going to reach into the drawer and see how many socks it took to make a pair.")
comPick = rd.choice(colors), \
          rd.choice(shapes)
Pairs = 0
running = True
ready = input("Are you ready to begin(yes/no): ").upper()
if ready == "YES":
    print("Alright lets begin!")
else:
    if ready == "NO":
        print("Too late im already starting.")
    else:
        print("Sorry I didn't catch that I was too occupied with taking socks out.")
while running:
    Pairs += 1
    perGuess = rd.choice(colors), \
               rd.choice(shapes)
    if perGuess == comPick:
        running = False
        print(comPick)
        print(perGuess)
        print(f" it took {Pairs} pairs to find a match")
        print("nice")
if Pairs > 20:
    print("That's a few socks")
print("There are still a large number of socks in here.")
print("Though we can look through more socks at another time")
goodbye = input(":")