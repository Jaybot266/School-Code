######################################
# Opening Comments
# Author Robert Ball
# 11/24/20
# Dealing with  Events and window Results
#######################################
import PySimpleGUI as sg
import random as rd

#Create the layout

# Function to create the 2nd window
def newWindow():
    longExplanation = 'This is a very detailed explanation of Nothing!!!'
    mySignature = 'Robert W Ball'
    PetName = 'The mighty Melody!!'
    layout2 = [[sg.Text('PySimpleGui - A called window',relief='solid',font=('Any',16),enable_events=True,key='-text2-',tooltip='This is float over help'),sg.Text('Powered by James Rumsey',enable_events=True,key='-Rumsey2-')],
          [sg.MLine(size=(30, 8), key='-Message2-')],
          [sg.Checkbox('Long Explanation ',default=False,enable_events=True,key='-check1-'),sg.Checkbox('Add Signature', default=False,enable_events=True,key='-check2-'),sg.Checkbox('Add Pet Name',enable_events=True,key='-check3-')],
          [sg.Button('Submit',key='-submit-',enable_events=True)],
          [sg.StatusBar("This is my status bar", key='-stat-')]]

    # Instatiate the window
    window2= sg.Window('New Window',layout2,modal=True)

    # Start the loop
    while True:
        event, values = window2.read()

        if event == sg.WINDOW_CLOSED or event == 'Quit':
            res = 'None'
            break
        elif event == '-check1-' or event == '-check2-' or event == '-check3-':
            window2['-Message2-'].update('', append = False)                    # Clear the box if not empty
            if values['-check1-']:
                window2['-Message2-'].update(longExplanation + '\n', append = True)
            if values['-check2-']:
                window2['-Message2-'].update(mySignature + '\n', append = True)
            if values['-check3-']:
                window2['-Message2-'].update(PetName + '\n', append = True)
        elif event == '-submit-':
            res = window2['-Message2-'].Get()
            break

    window2.close()
    return res






# Set the theme
sg.theme('LightBlue2')
combolist = ['Green Backgrounds','White Backgrounds','Yellow Backgrounds']

layout = [[sg.Text('PySimpleGui - How to get screen input',relief='sunken',font=('Any',16),enable_events=True,key='-text-'),sg.Text('Powered by James Rumsey',enable_events=True,key='-Rumsey-')],
          [sg.InputText('',password_char='?',key='-pass-',size=(60,1)),sg.Text('Show',key='-show-',enable_events=True)],
          [sg.MLine(size=(30, 8), key='-Message-'),sg.MLine(size=(30,8),key='-values-',disabled=True)],
          [sg.Radio('Radio1','G1',default=False,key='-r1-'),sg.Radio('Radio2','G1',default=True,key='-r2-'),sg.Radio('Radio3','G1',default=False,key='-r3-'),
            sg.Combo(combolist,key='-combo-',default_value='White Backgrounds',enable_events=True)],
          [sg.Button('Remove Values Window', key='-rvalues-'),sg.Checkbox('Do not click me!!',default=False,enable_events=True,key='-check-'),sg.Button('New Window',key='-NewWindow-'),sg.Text('Show Values',key='-svalues-',enable_events=True)],
          [sg.StatusBar("This is my status bar", key='-stat-')]]

# Create the instance of the window
window = sg.Window('Demo Window',layout)
DCheck = ['I said do not check me!','Enough already!','Ouch that hurts!!','You are getting on my nerves','I\'m calling the cop\'s!!', 'How bout I check you in the head!']

#start the while loop
#There are a lot of events, I'll seperate by comments
while True:
    event, values = window.read()
    print(event,values)
    if event == sg.WINDOW_CLOSED or event == 'Quit':
        break
    #  Clicked on main title Text
    elif event == '-text-':
        sg.PopupQuickMessage('Coding at James Rumsey is the best!!!',auto_close_duration=4)
        window['-stat-'].update('Text Clicked')
    #   Clicked on Rumsey Text

    elif event == '-Rumsey-':
        sg.popup_ok('Go JRTI!!!!')
    #   Clicked on Show text, display password in the status bar

    elif event == '-show-':
        window['-stat-'].update(values['-pass-'])

    #   Clicked on Combo Box, changes background colors on input fields

    elif event == '-combo-':
        if values['-combo-'] == 'White Backgrounds':
            window['-Message-'].update(background_color = 'White')
            window['-pass-'].update(background_color = 'White')
            window['-values-'].update(background_color = 'White')
        elif values['-combo-'] == 'Green Backgrounds':
            window['-Message-'].update(background_color='Green')
            window['-pass-'].update(background_color = 'Green')
            window['-values-'].update(background_color = 'Green')
        elif values['-combo-'] == 'Yellow Backgrounds':
            window['-Message-'].update(background_color='Yellow')
            window['-pass-'].update(background_color = 'Yellow')
            window['-values-'].update(background_color = 'Yellow')
        window['-stat-'].update('Combo Choice made')

    # Clicked on Radio 1, Radio 2 or Radio 3

    elif event == '-r1-':
        window['-stat-'].update('Radio 1 it is!')
    elif event == '-r2-':
        window['-stat-'].update('Radio 2 it is!')
    elif event == '-r3-':
        window['-stat-'].update('Radio 3 it is!')

    # Clicked on the Show or Hide Values window Button

    elif event == '-rvalues-':
        if window['-rvalues-'].GetText() == 'Show Values Window':
            window['-values-'].update(visible=True)
            window['-svalues-'].update(visible=True)
            window['-rvalues-'].update('Remove Values Window')
        else:
            window['-values-'].update(visible=False)
            window['-svalues-'].update(visible=False)
            window['-rvalues-'].update('Show Values Window')

        window['-stat-'].update('Remove Values Window')

   # Clicked on the Check Box

    elif event == '-check-':
        window['-stat-'].update('Oh no you did\'t!!!!')
        response = rd.choice(DCheck)
        sg.popup_ok(response)
        window['-check-'].update(False)

    # Clicked on the New Window Button

    elif event == '-NewWindow-':
        window['-stat-'].update('New Window')
        result = newWindow()
        window['-Message-'].update(result,append=False)
        print(result)

    # Clicked on the show values button

    elif event == '-svalues-':
        window['-values-'].update('',append=False)
        Output = 'Pass:' + values['-pass-'] + ' \n'
        window['-values-'].update(Output,append=True)
        Output = 'Message:' + values['-Message-'] + '\n'
        window['-values-'].update(Output,append=True)
        Output = 'Combo:' + values['-combo-'] + '\n'
        window['-values-'].update(Output,append=True)
        Output = 'Radio 1:' + str(values['-r1-']) + '\n'
        window['-values-'].update(Output,append=True)
        Output = 'Radio 2:' + str(values['-r2-']) + '\n'
        window['-values-'].update(Output,append=True)
        Output = 'Radio 3:' + str(values['-r3-']) + '\n'
        window['-values-'].update(Output,append=True)
        Output = 'Check Box:' + str(values['-check-']) + '\n'
        window['-values-'].update(Output,append=True)
    else:
        print(event,values)

window.close()
