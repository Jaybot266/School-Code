Creating a list:

•	MyList = []   - Notice ‘Square brackets’
•	Lists can contain any data type, even mixed.
•	Examples
o	Fruit = [‘Apple’, ‘Pear’,’Strawberry’,’Orange’]
o	Ages = [16, 28,22,30,55]
o	Mixed = [5,’Peanuts’,’Walnuts’,17]
o	EmptyList = []
Adding to a list:
•	append – This adds to the end of a list
o	Fruit.append(‘Grape’)
•	insert – inserts at a specified position
o	Fruit.insert(1, “Blueberry)

Removing Items from a list
•	clear – Removes all items from a list
o	Fruit.clear()
•	pop() – Destructive Read, Default is -1 or the last item on the list
o	Fruit.pop() – Would return “Orange”
o	Fruit.pop(0) – Would return “Apple
o	Fruit.remove(‘Pear’)
Accessing items on a list.
•	pop() – you can use pop, just remember it is a destructive read
•	Direct
o	myFruit = Fruit[2] would return “Strawberry”
Additional
•	copy – returns a copy of the list
•	count – returns the count of elements with a certain value
•	extend – Add elements of another list to the list
•	index – returns the index of the first element with the specified value
•	reverse – reverses the list
•	sort – sorts the list
List iteration:

List can be read in a loop or iteration
myList = [“Bob”,”Kenda”,”Alex”,”Robyn”,”Ray”,”Maddy”]
for name in myList:
	print(name)

Random:
Import random as rd

myName = rd.choice(myList)
