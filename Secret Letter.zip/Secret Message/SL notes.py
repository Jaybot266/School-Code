myFile = open("EncryptFile.txt", "w")
myFile.write("This is a test")
myFile.close()

LongFile = open("EncryptFile.txt", "r")
allText = LongFile.readlines()
for line in allText:
    print(allText)

NewFile = open("newFile.txt", "a")
for nLine in allText:
    NewFile.write(nLine)
NewFile.close()
LongFile.close()