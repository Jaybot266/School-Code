import PySimpleGUI as sg


sg.theme("LightGreen2")
combolist = ["Green Backgrounds", 'White Backgrounds', 'Yellow Backgrounds']

layout = [[sg.Text("PySimpleGUI-First Window", relief="sunken", font=('Any', 16), key='-text-'), sg.Text('Powered by JRTI Software', enable_events=True, key='-Rumsey-')],
        [sg.InputText('', password_char='*', key='-pass-', size=(60,1)), sg.Text('Show', key='-show-', enable_events=True)],
        [sg.MLine(size=(30, 8), key='-Message-'), sg.MLine(size=(30, 8), key='-values-', disabled=True)],
        [sg.Radio('Radio1','G1',default=False, key='-r1'),sg.Radio('Radio2','G1',default=False, key='-r1'),sg.Radio('Radio3','G1',default=False, key='-r1')],
        [sg.Combo(combolist, key='-combo-', default_value='White Background', enable_events=True)],
        [sg.Button('Remove Values Window', key='-rvalues-'),
        sg.Checkbox('Do not click me!!!', default = False, enable_events=True, key='check-'),
        sg.Button('New Window', key='-NewWindow-'), sg.Text('Show Values', key='-svalues-', enable_events=True)],
        [sg.StatusBar("This is my status bar", key='-stat-')]
        ]
window = sg.Window("First window", layout, resizable=True)

while True:
    event, values = window.read()
    print(event, values)
    if event == sg.WINDOW_CLOSED or event == 'Quit':
        break