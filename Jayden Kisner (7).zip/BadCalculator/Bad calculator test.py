#Jayden Kisner
#9/13/22
#Bad cal test:
import math
operator = ['*', '+', '-', '/']
SandEcounter = {"Successful transactions": 0, "Error transactions": 0}
def update_SandE(key):
    SandEcounter[key] += 1
    return

def calculate():
    if perOp == '+':
        return uNum1 + uNum2
    if perOp == '*':
        return uNum1 * uNum2
    if perOp == '/':
        return uNum1 / uNum2
    if perOp == '-':
        return uNum1 - uNum2

running = True
while running:
    num1 = input("Please enter a number: ")
    num2 = input("Enter another number: ")
    perOp = input("Please chose an operator (+,-,*,/): ")
    try:
        uNum1 = int(num1)
        uNum2 = int(num2)
        update_SandE("Successful transactions")
        print(calculate())
    except Exception as e:
        print(f"Something wrong you did.")
        print(f"Your exceptions says: {e}")
        update_SandE("Error transactions")
    theQue = input("Would you like to play again? (Y/N):").upper()
    if theQue == "N":
        print("Alright then.")
        running = False
        print(SandEcounter)