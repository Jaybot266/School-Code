#More test
import random as rd

print('Hey friend how have you been?')
chIce = input("Hey I can up with a new game to play. Would you like to play it?").upper()
if chIce == "YES":
    print("Let's play!")
else:
    print("I can't understand you, so I am going to assume you said yes.")
trIes = 1
thEre = input("Guess my Number:")
perGuess = int(thEre)
comNum = rd.randint(1, 200000)
if perGuess == comNum:
    print("nice")
    print(comNum)
if perGuess != comNum:
    trIes += 1
    print("Not yet")
    perGuess = input("Try again")
    perGuess = input("One more attempt")
if trIes == 3:
    print("Too Bad you lost")
