
import random as rd


class Dog():
    def __init__(self, name, color):
        self.name = name
        self.color = color
        moodList = ["Happy", "Angry", "Sad", "Excited", "Hungry"]
        self.temperment = rd.choice(moodList)

    def getMood(self):
        return self.temperment

    def speak(self):
        print(f"{self.name} the {self.color} says Woof Woof and is {self.temperment}")

    def isSitting(self):
        isSitting = rd.choice([True,False])
        if isSitting:
            print("         yes, I am sitting")
        else:
            print("         no, I am not sitting")

    def getDogInfo(self):
        dInfo = f"{self.name} is {self.color}"
        return dInfo




nameList = ["Bob", "Kenda", "Maddy", "Sam", "Jay", "Jayden", "Gavin", "Storm", "Cedar", "Ian", "Evelyn", "Wyatt", "Trenton"]
colorList = ["Brown", "Yellow", "Grey", "Black", "White", "Tan", "Red", "Orange"]
dogList = []
for i in range(50):
    dog = Dog(rd.choice(nameList), rd.choice(colorList))
    dog.speak()
    dog.isSitting()
    dogList.append(dog.getDogInfo())

print(dogList)
