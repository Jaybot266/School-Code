#Jayden Kisner
#10/3/23
#Multimedia Gallery Database: Using SSQL and A tkinter GUI to make gallery for images and multimedia files
#For storing images in SQL https://www.youtube.com/watch?v=d4L1J9ABhD8
#To play videos https://pypi.org/project/tkvideoplayer/

from tkinter import *
from tkinter import ttk, messagebox
from tkinter import Toplevel
from tkinter import filedialog
import sqlite3

#def create_tab1(parent_frame):
    #def create

#This is how you will be able to make another window
def addingSql():

    def pullInfo():
        conn = sqlite3.connect('Gallery_Database.db')

        c = conn.cursor()

        c.execute("INSERT INTO More_Info VALUES(:File_Type, :Name, :Tags, :Date, :File) ",
                  {
                    'File_Type':iType.get(),
                    'Name':iName.get(),
                    'Tags':pTags.get(),
                    'Date':pDate.get(),
                    'File':uMedia.get()

                  }

                  )

        conn.commit()

        if cInfo is clicked:

            inAdd = messagebox.showinfo("Saved", "You info has been saved")
        print("Info saved")

        conn.close()

    def goBack():
        Add.destroy()

    def tags():
        new = Toplevel()
        bCheck = Checkbutton(new, text="Big")

        bCheck.grid(row=0, column=0)


    #Her's the info for the drop down box
    Type =["Image",
           "Video",
           "Audio"]
    clicked = StringVar()

    #Interact ables
    Add = Toplevel()

    #All the text in the window
    uName = Label(Add,text="Please enter your media's name")
    uType = Label(Add, text="What is you media's type?")
    oFile = Label(Add, text="Please select your file")
    tDate = Label(Add, text="What is the date of today?")
    sTag = Label(Add, text="Select the tag(s) that best describe your item")

    #All the Buttons in the window
    uMedia = Entry(Add)
    Bye = Button(Add, text="Back", command=goBack)
    #uMedia = Button(Add, text=("Open File"))
    cInfo = Button(Add, text="Add", command=pullInfo)
    pTags = Entry(Add)
    #pTags = Button(Add, text="Tags", command=tags())

    #Others
    iName = Entry(Add)
    pDate = Entry(Add)
    iType = Entry(Add)
    #iType = OptionMenu(Add, clicked, *Type)

    #Location
    uName.grid(row=0, column=0)
    iName.grid(row=0, column=1)
    uType.grid(row=1, column=0)
    iType.grid(row=1, column=1)
    oFile.grid(row=2, column=0)
    uMedia.grid(row=2, column=1)
    tDate.grid(row=3, column=0)
    pDate.grid(row=3, column=1)
    sTag.grid(row=4, column=0)
    pTags.grid(row=4, column=1)
    cInfo.grid(row=8, column=0, padx=(0,200))
    Bye.grid(row=8, column=1)

def delete():
    conn = sqlite3.connect('Gallery_Database.db')

    c = conn.cursor()
    #delin = messagebox.askyesno("Deleting a image", "Are you sure you want to delete this item?")



    c.execute("DELETE from More_Info WHERE Name = " + test.get())


    print("Info gone")

    conn.commit()

    conn.close()



def filSql():
    filter = Toplevel()

    cb1 = Checkbutton(filter, text="Big")
    cb2 = Checkbutton(filter, text="Small")
    cb3 = Checkbutton(filter, text="Family")
    cb4 = Checkbutton(filter, text="Friends")
    cb5 = Checkbutton(filter, text="Happy")
    cb6 = Checkbutton(filter, text="Memories")
    cb7 = Checkbutton(filter, text="?")

    cb1.grid(row=0, column=0)
    cb2.grid(row=0, column=1)
    cb3.grid(row=0, column=2)
    cb4.grid(row=1, column=0)
    cb5.grid(row=1, column=1)
    cb6.grid(row=1, column=2)
    cb7.grid(row=3, column=0)



def openSql():
    conn = sqlite3.connect('Gallery_Database.db')

    c = conn.cursor()

    c.execute("SELECT *, oid FROM More_Info")
    records = c.fetchall()
    print(records)
    print_records = ''

    for record in records:
        print_records += str(record) + "\n"

    query_label = Label(root, text=print_records)
    query_label.grid(row=5, column=0)

    conn.commit()

    conn.close()



root = Tk()


#This is were you would add you text
basics = Label(root, text="Welcome to multimedia storage")
space = Label(root, text="          ")

#Place buttons here that are used on window
filBut = Button(root, text="Filter", command=filSql)
addBut = Button(root, text="Add", command=addingSql)
delInfo = Button(root, text="Delete", command=delete)
opSql = Button(root, text="Open", command=openSql())
test = Entry(root)
test2 = Button(root, text="Bye", command=delete)

#style = ttk.Style(parent_frame)

#Where each of the aspects are placed in the window

basics.grid(row=0, column=0, padx=0, pady=1)
space.grid(row=0, column=1)
filBut.grid(row=0, column=2)
addBut.grid(row=2, column=0, padx=(1,65), pady=(5, 5))
delInfo.grid(row=2, column=0, padx=(50, 30), pady=(5, 5))
opSql.grid(row=2, column=0, padx=(120,10))
test.grid(row=80, column=0)
test2.grid(row=81,column=0)


root.mainloop()
