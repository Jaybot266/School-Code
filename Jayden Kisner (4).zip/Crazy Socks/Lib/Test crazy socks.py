#Jayden Kisner
#8/30/22
#Crazy Socks- test for now

import random as rd

colors = ["red", "green", "blue", "indego", "violet", "orange", "yellow", "pink", "white", "black"]
shapes = ["squares", "circles", "rectangle", "pyramid", "trangle", "rombus", "star", "heart", "fish", ]
comPick = rd.choice(colors), rd.choice(shapes)
Pairs = 0
running = True
while running:
    Pairs += 1
    perGuess = rd.choice(colors), rd.choice(shapes)
    if perGuess == comPick:
        running = False
        print(comPick)
        print(perGuess)
        print(f" it took {Pairs} pairs to find a match")
        print("nice")