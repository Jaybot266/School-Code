#Jayden Kisner
#3/15/23
#Dictonary update - Using and input statement to count the numbers of letters and numbers in the input using dictionary

pSen = input("Please write a sentence and I will count how many letters nd numbers are in it:\n")


