yeet= {"Good": 8, "Bad": 9}
print(yeet)
yeet["Bad"] -= 1
print(yeet)