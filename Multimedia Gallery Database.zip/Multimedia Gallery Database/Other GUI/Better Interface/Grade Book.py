# Jayden Kisner
# 10/17/22
# More indept interface
import PySimpleGUI as sg

sg.theme("BrownBlue")

#I liked the design of Sam's add a student more than mine
def numofStudents():
    layout = [[sg.Text('Enter')],
              [sg.Text('Last Name'), sg.Input(key='-firstName-')],
              [sg.Text('First Name'), sg.Input(key='-lastName-')],
              [sg.HorizontalSeparator()],
              [sg.Text('  Home School'), sg.Text('         '), sg.Radio('11th grade', group_id='grade', key='-11th-'),
               sg.Text(''), sg.Radio('12th grade', group_id='grade', key='-12th-')],
              [sg.Listbox(Schools, size=(30, 4), key='-schools-'),
               sg.Text('   '), sg.Text('Average Grade '), sg.Input(size=(10, 10), key='-averageGrade-'), sg.Text('%')],
              [sg.Text('                                 '), sg.Radio('all day', group_id='day', key='-allday-'),
               sg.Radio('half day', group_id='day', key='-halfday-')],
              [sg.HorizontalSeparator()],
              [sg.Text()],
              [sg.Button('Save information', key='-save-')]]

    Window2 = sg.Window("Adding a student", layout, modal=True)

    while True:
        event, values = Window2.read()
        print(event, values)
        if event == sg.WINDOW_CLOSED or event == 'Quit':
            res = 'None'
            break

#Let me know if making the information filter is harder than I first thought, and I'll change the design
def highschool():
    layout3 = [[sg.Text("Students at each high school")],
               [sg.Text("Filter"), sg.Combo(Schools, size=(25,9))],
               [sg.MLine(size=(40,9))]
               ]
    Window3 = sg.Window("High Schools", layout3, modal=True)

    while True:
        event, values = Window3.read()
        print(event, values)
        if event == sg.WINDOW_CLOSED or event == 'Quit':
            res = 'None'
            break

#Once the program can pickle it should keep track of the number of students
def totalstudents():
    Numstu = [[sg.Text("There is a total of (Number) of students in the system.")],]
    Window4 = sg.Window("Total", Numstu, modal=True)
    while True:
        event, values = Window4.read()
        print(event, values)
        if event == sg.WINDOW_CLOSED or event == 'Quit':
            res = 'None'
            break

#Once the pickle is added it should display the students name, and they should be able to select their name.
#If this is hard I can change the design
def delete():
    Layout5 = [[sg.Text("Would you like to delete (Student Name)")],
               [sg.Text("                 "),
                sg.Button("Yes"),
                sg.Button("No")]]
    Window5 = sg.Window("Total", Layout5, modal=True)
    while True:
        event, values = Window5.read()
        print(event, values)
        if event == sg.WINDOW_CLOSED or event == 'Quit':
            res = 'None'
            break

#I put default values in this window to show what it would look like when you edit the person's profile
def edit():
    Layout6 = [[sg.Text('Enter')],
              [sg.Text('Last Name'),
                    sg.Input(("John"), key='-firstName-')],
              [sg.Text('First Name'),
                    sg.Input(("Beagle"), key='-lastName-')],
              [sg.HorizontalSeparator()],
              [sg.Text('  Home School'),
                sg.Text('         '),
                sg.Radio('11th grade', group_id='grade', key='-11th-', default = True),
                sg.Text(''), sg.Radio('12th grade', group_id='grade', key='-12th-')],
              [sg.Listbox(Schools, size=(30, 4), key='-schools-', default_values= ['Hedgesville High School']),
                sg.Text('   '),
                sg.Text('Average Grade '),
                sg.Input((89), size=(10, 10), key='-averageGrade-'),
                sg.Text('%')],
              [sg.Text('                                 '),
                sg.Radio('all day', group_id='day', key='-allday-'),
                sg.Radio('half day', group_id='day', key='-halfday-', default=True)],
              [sg.HorizontalSeparator()],
              [sg.Text()],
              [sg.Button('Save information', key='-save-')]]

    Window6 = sg.Window("Adding a student", Layout6, modal=True)

    while True:
        event, values = Window6.read()
        print(event, values)
        if event == sg.WINDOW_CLOSED or event == 'Quit':
            res = 'None'
            break

Attendence = ["All Day", "Half-day morning", "Half-day evening"]
Schools = ["Spring Mills High School", "Hedgesville High School", "MartinsBurg High School", "Berkeley Springs High School","Jefferson High School", "Musselman High School", "Washington High School", "Paw Paw High School"]

#It might be good to change the MLine to a Listbox so people could actually click the students name
layout2 = [[sg.Text("Student List"),
            sg.Button('Total Number of Students', enable_events=True, key='-Numstu-'),
            sg.Button('Students per High school', enable_events=True, key='-Stuhigh-')],
           [sg.MLine(("John Beagle"), size=(60, 8), key='-List-')],
           [sg.Button('Edit', enable_events=True, key='-Edit-'),
            sg.Button('Delete', enable_events=True, key='-Delete-'),
            sg.Button('Add', enable_events=True, key='-Add-')],
           ]

window = sg.Window("GradeBook-JRTI", layout2)
while True:
    event, values = window.read()
    print(event, values)
    if event == sg.WINDOW_CLOSED or event == 'Quit':
        break
    elif event == '-Add-':
        list = numofStudents()
        print(list)
    elif event =='-Stuhigh-':
        cata = highschool()
        print(cata)
    elif event == '-Numstu-':
        Total = totalstudents()
        print(Total)
    elif event == '-Delete-':
        Gone = delete()
        print(Gone)
    elif event == '-Edit-':
        Add = edit()
        print(Add)