#Jayden Kisner
#9/29/23
#Multimedia Gallery Database: Using SSQL and A PY GUI to make gallery for images and multimedia files
#https://pynative.com/python-sqlite-blob-insert-and-retrieve-digital-data/ (to see how to do images0
import PySimpleGUI as sg
import sqlite3
from sqlite3 import Error

def getDbConnection():
    conn = None

    try:
        conn = sqlite3.connect("Gallery_Database.db")
    except Error as e:
        print(e)
    return conn

#Here's where you add things
def AddMedia():
    layout2 = [[sg.Titlebar("Adding")],
               [sg.Text("Name"), sg.InputText(key='-Name-')],
               [sg.Text("What type of Media is it?"),
                    sg.Radio("Image", group_id='-type-', key='Image'),
                    sg.Radio("Video", group_id='-type', key='-Video')],
               [sg.Text("Please select the following tag(s) that best describes your image"),
                    sg.Button("Tags", key='-Tag-')],
               [sg.Button("Add", key='-Put-')]
               ]

    window2 = sg.Window("Nice", layout2, modal=True)

    while True:
        event, values = window2.read()
        if event == sg.WINDOW_CLOSED or event == 'Quit':
            break
        if event == '-Put-':
            con = getDbConnection()
            curr = con.cursor()

            GetInfo = DB.insert_info()[values['-Name-'], values['-Image-'], values['-Video-'], values['-tag-']]
            sg.popup("Info sent")
        if DB.Error:
            sg.popup("error_message")

def Filter():
    layout6 = [[sg.Checkbox("Big"), sg.Checkbox("Small"),sg.Checkbox("Family")]]

    window6 = sg.Window("Filt", layout6, modal=True)

    while True:
        event, values = window6.read()
        if event == sg.WINDOW_CLOSED or event == 'Quit':
            break

#How you are able to delete things
def Delete():
    layout3 = [[sg.Titlebar("Delete")],
               [sg.Text("Are you sure you want to delet {File_name}?")],
               [sg.Push(),sg.Radio("Yes", group_id='-Del-'),
                sg.Radio("No", group_id='-Del-'),sg.Push()],
               [sg.Push(),sg.Button("Enter", key='-Bye-', enable_events=True),sg.Push()]
               ]

    window3 = sg.Window("Nice", layout3, modal=True)

    while True:
        event, values = window3.read()
        if event == sg.WINDOW_CLOSED or event == 'Quit':
            break
        if event == '-Bye-':
            break
            window3.close

def Open():
    layout4 = [[sg.Titlebar("Viewing")],
               [sg.MLine(size=(40,9))],
               [sg.Button("Back", key='-Back-')]
               ]

    window4 = sg.Window("Nice", layout4, modal=True)

    while True:
        event, values = window4.read()
        if event == sg.WINDOW_CLOSED or event == 'Quit':
            break
        elif event == '-Back-':
            Value = 1

def Sort():
    layout4 = 2


def Main():
    #This is the Main widow
    layout1 = [[sg.Titlebar("Data", key='-Start-')],
                [sg.Text("                                                                                                                "),
                 #Exist beside each other on the GUI
                    sg.Button("Filter", key='-Filt-')],
                [sg.MLine(size=(70,9))],
                [sg.Button("Add", key='-Add-', enable_events=True),
                    sg.Button("Delete", key='-Gone-'),
                    sg.Button("Open", key='Open')]
               ]

    window1 = sg.Window("Test", layout1, modal=True)


    #Creation of Window
    while True:
        event, values = window1.read()
        if event == sg.WINDOW_CLOSED or event == 'Quit':
            break
        elif event == '-Add-':
            list = AddMedia()
        elif event == '-Gone-':
            Bye = Delete()
        elif event == 'Open':
            Get = Open()
        elif event == '-Filt-':
            What = Filter()



layout5 = [[sg.Button("Open", key='-Start-', enable_events=True)]]

window5 = sg.Window("Test", layout5)
while True:
    event, values = window5.read()
    if event == sg.WINDOW_CLOSED or event == 'Quit':
        break
    if event == '-Start-':
        start = Main()
        break
    window5.close()
