import random as rd

print('Hey friend how have you been?')
chIce = input("Hey I can up with a new game to play. Would you like to play it?").upper()
if chIce == "YES":
    print("Let's play!")
else:
    print("I can't understand you, so I am going to assume you said yes.")
trIes = 0
thEre = input("Guess my Number:")
perGuess =int(thEre)
comNum = rd.randint(1,2)
running = True
while running:
    if perGuess == comNum:
        running = False
    print("nice")
    print(comNum)
