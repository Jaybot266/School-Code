import tkinter as tk
from tkinter import ttk


def create_tab2(parent_frame):
    label = tk.Label(parent_frame, text='Welcome to GUI 2')
    label.pack(pady=10)
