#Jayden Kisner
#9/28/22
#Random Chef = Keeping track of what a chef buys over a certain amount of days using list of list
import random as rd


InList = ["Pasta", "Strawberries", "Avocados", "Ground Beef", "Oranges", "Pepper", "Salt", "Pork", "Bread", "Lettuce", "Ginger", "Basil", "apples", "Eggs", "Carrots", "Butter", "Potatoes", "Bacon", "Tomatoes", "Paprika", "Squids", "Crabs", "Onions", "Chocolate", "Spaghetti sauce", "oysters", "Milk", "Pears", "Fish", "Dill", "Spinach", "Chicken", "Chips", "Shrimp", "Beans", "Peas", "Peanuts", "Cheese", "Turkey", "Dragon Fruit", "Eggplants", "Cherrys", "Kale", "Yellow peppers", "Celery", "Taco Shells", "Broccoli", "A Watermelon", "Blueberries", "Rice"]

Shopping = True

Days = 0

TotalItems = []

print("Hello Amigo, I have meet a new Amigo!")
print("Her name is Susie and she is a chef, and likes to come up with random meals.")
print("She mostly figures out these recipes out by going to the store each day, and picking out random items.")
print("This time she wants help with shopping and would be wondering if you could help.")
HelpHer = input("Would you like to help her?(Y/N): ").upper()
if HelpHer == "Y":
    print("Gracias Amigo, Susie will very thankful.")
else:
    if HelpHer == "N":
        print("Well that's just rude, now your definitely going to help.")
    else:
        print("Amigo I don't understand what you are trying to say, but I am going to assume you ment yes.")


while Shopping:
    try:
        Items = int(input("How many time do you want to go shopping with her?: "))
        Shopping = False
    except:
            print("That is not a number, please enter a number.")
for i in range(Items):
    Days += 1
    ItemsGot = []
    for i in range(5):
        Steve = rd.choice(InList)
        ItemsGot.append(Steve)
        TotalItems.append(Steve)
    print(f"On day {Days} you guys got {ItemsGot}")
    print(" ")
print(f"In total the both of you got {TotalItems}, after {Days} Days.")
print("I hope you and Susie enjoyed the interesting dinner you guys made with those items.")
print("Susie seems happy with the comidas, I hope you enjoyed them Amigo.")
print("Well adiós amigo")
Goodbye = input(":")