#Jayden Kisner
#9/21/22
#Secret Message = Encrypting a message from the user and then being abla to decrypt the message if they are using the same key

running = True
def nodupes(string):
    newstring = ''
    for i in string:
        if i not in newstring:
            newstring += i
    return newstring


def buildcypherdict(CypherString,PlainString):
    cypherdict =  {}
    clen = len(CypherString)
    for i in range(0, clen -1):
        cypherdict[PlainString[i]] = CypherString[i]
    return cypherdict


def buildDecypherdict(PlainString,CypherString):
    Decypherdict =  {}
    clen = len(CypherString)
    for i in range(0, clen -1):
        Decypherdict[CypherString[i]] = PlainString[i]
    return Decypherdict


def changemsg(message,dictonary):
    newMsg = ''
    for i in range(0, len(message)):
        value = dictonary.get(message[i], "Empty")
        if value == "Empty":
            newMsg += message[i]
        else:
            newMsg += value
    return newMsg

print("Hola amigo, I have come up with a way we could talk in secret.")
print("Don't worry I'll do all the work all you have to do is tell me what you want encrypted.")
print("I also ask that you give me a key so that only those who know it can decrypt your message.")
print("Ok lets begin.")


keyword = input("Please enter a key that is at least 3 letters long and with minial special characters and numbers: ")
while (len(keyword) < 3):
    keyword = input("That doesn't seem long enough. Try to make it longer: ")
    keyword = nodupes(keyword)


PlainString = ('abcdefghijklmnopqrstuvwxyzABCEDFGHIJKLMNOPQRSTUVWXYZ0123456789.,-/?!$% ')
CypherString = (nodupes(keyword +'zyxwvutsrqponmlkjihgfedcbaZYXWVUTSRQPONMLKJIHGFEDCBA9876543210%$!?/-,. '))

UsetoEncrypt = buildcypherdict(CypherString, PlainString)
UsetoDecrypt = buildDecypherdict(PlainString,CypherString)
useCho = input("Would you like to Encrypt or Decrypt \n")

while running:
    if (useCho.upper() == "ENCRYPT"):
        useMessage = input("What is your message you want to Encrypt?: ")
        useMessage = changemsg(useMessage, UsetoEncrypt)
        print(f"Your encrypted message is ({useMessage})")
        running = False
    else:
        if  (useCho.upper() == "DECRYPT"):
            useMessage = input("What would you like to Decrypt: ")
            useMessage = changemsg(useMessage, UsetoDecrypt)
            print(f"Your decrypted message is ({useMessage})")
            running = False
        else:
            if useCho != 'ENCRYPT' or 'DECRYPT':
                print("That is an option, please try again. \n")
                useCho = input("Encrypt or Decrypt \n")
print("I hope that you are happy with the results Amigo.")
print("Goodbye Amigo, call me if you want to encrypt again or decrypt a message.")
goodbye = input(":")