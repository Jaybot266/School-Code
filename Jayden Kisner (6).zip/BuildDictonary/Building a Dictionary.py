#Jayden Kisner
#9/12/22
#Build a Dictonary = making a dictonary using a list
keys = ['Blue', 'Red', 'Yellow', 'Orange', 'Purple', 'Mauve', 'Pink']
values = [0, 1, 2, 3, 4, 5, 6, 7]
myDict = {}
for i in range(len(keys)):
    if len(keys) == len(values):
        myDict[keys[i]] = values[i]
    else:
        print("Error")
print(myDict)