#Jayden Kisner
#10/31/22
#FoodServer = Using OOP to simulate a resturant
import random as rd