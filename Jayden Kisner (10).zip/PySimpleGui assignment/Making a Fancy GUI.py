#Jayden Kisner
#10/5/22
#Create for me a fancy GUI = Using PySimpleGUI to make a window that look like it does something
import PySimpleGUI as sg

sg.theme("LightGrey2")
Days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
Time = ['Morning', 'Afternoon', 'Evening', 'AM', 'PM']
Size = ['XXS', 'XS', 'S', 'M', 'L', 'XL', 'XXl']
Gender = ['Male', 'Female', 'Other']

layout = [[sg.Titlebar("Crazy Socks Fan club", font=('Any', 20), key='-Start-')],
        [sg.Text("Thank you for deciding to join. By signing up you will receive a new pair of socks each month."),
        sg.Text("Happy Halloween"), sg.Image(filename='Little pump.png')],
        [sg.Text("Please enter your name."),
            sg.InputText("", key="-Name-", font=(12, 10))],
        [sg.Text("Please enter your phone number."),
            sg.InputText("", key='-Phone-', font=(12, 10))],
        [sg.Text("Please enter your address."),
            sg.InputText("", key='-address-', font=(12, 10))],
        [sg.Text('In the box below write which colors and designs you like the most. (This step is optional)')],
        [sg.MLine(size=(60, 8), key='List')],
        [sg.Text('Please enter your size.'), sg.Combo(Size),
            sg.Text('What is your Gender?'), sg.Combo(Gender)],
        [sg.Text('What would be a good day for delivery?'),
            sg.Combo(Days, key='-Days-', default_value='Monday', enable_events=True),
            sg.Text('What time would you too receive the delivery at.'),
            sg.Listbox(Time)],
        [sg.Text("How long would you like to subscribe to the service for?"),
            sg.Radio("1 month ($2)", 'S1', default=True, key='-C1', enable_events=True),
            sg.Radio("6 month ($10)", 'S1', default=False, key='-C1', enable_events=True),
            sg.Radio("12 month ($18)", 'S1', default=False, key='-C1', enable_events=True)],
        [sg.Text("Please read the terms and conditions, and then click the check box to agree to them."),
            sg.Button('Terms and Conditions', key='-Term-', enable_events=True),
            sg.Checkbox("I agree", key='-Agree-', enable_events=True)],
        [sg.Text('Click the save button once you have filled out the form.'),
            sg.Button('Save', key="-save-", enable_events=True)],
        ]

window = sg.Window("Crazy Socks Fan club", layout)

while True:
    event, values = window.read()
    print(event, values)
    if event == sg.WINDOW_CLOSED or event == 'Quit':
        break