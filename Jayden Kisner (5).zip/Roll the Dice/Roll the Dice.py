#Jayden Kisner
#9/6/22
#Roll the Dice = Use libaries to keep track of wins and loses, and how many times each number was rolled.
import random as rd
print("Hey Friend! I came up with a new game we could play.")
print("In this game we both roll a dice, and who ever gets the bigger nuber wins")
print("I will keep track of how many wins and loses you have, and how many times you rolled each number.")
numRou = 0
myDict = {"Wins": 0, "Loses": 0, "Ties":0}
numRoll = {"One": 0, "Two": 0, "Three": 0, "Four": 0, "Five": 0, "Six": 0}
running = True
while running:
    perCho = input("Would you like to play?(y/n): ").upper()
    if perCho == "Y":
        comNum = rd.randint(1, 6)
        myNum = rd.randint(1, 6)
        numRou +=1
        print("...")
        print(f"I rolled a {comNum}, and you rolled a {myNum}")
        if comNum < myNum:
            print("You won, Congratulations!")
            myDict["Wins"]+=1
            print(myDict)
#This was the best way I could figure out how to track the number of rolls for each number.
            if myNum == 1:
                numRoll["One"]+=1
            else:
                if myNum == 2:
                    numRoll["Two"]+=1
                else:
                    if myNum == 3:
                        numRoll["Three"]+=1
                    else:
                        if myNum == 4:
                            numRoll["Four"]+=1
                        else:
                            if myNum == 5:
                                numRoll["Five"]+=1
                            else:
                                if myNum == 6:
                                    numRoll["Six"]+=1
        else:
            if comNum > myNum:
                print("You Lost, better luck next time.")
                myDict["Loses"]+=1
                print(myDict)
                if myNum == 1:
                    numRoll["One"] += 1
                else:
                    if myNum == 2:
                        numRoll["Two"] += 1
                    else:
                        if myNum == 3:
                            numRoll["Three"] += 1
                        else:
                            if myNum == 4:
                                numRoll["Four"] += 1
                            else:
                                if myNum == 5:
                                    numRoll["Five"] += 1
                                else:
                                    if myNum == 6:
                                        numRoll["Six"] += 1
            else:
                if comNum == myNum:
                    print("We seemed to have gotten a tie")
                    myDict["Ties"]+=1
                    print(myDict)
                    if myNum == 1:
                        numRoll["One"] += 1
                    else:
                        if myNum == 2:
                            numRoll["Two"] += 1
                        else:
                            if myNum == 3:
                                numRoll["Three"] += 1
                            else:
                                if myNum == 4:
                                    numRoll["Four"] += 1
                                else:
                                    if myNum == 5:
                                        numRoll["Five"] += 1
                                    else:
                                        if myNum == 6:
                                            numRoll["Six"] += 1
        print(numRoll)
    else:
        if perCho == "N":
            running = False
            numCop = numRoll.copy()
            numWins = myDict.get("Wins")
            numLose = myDict.get("Loses")
            numTies = myDict.get("Ties")
            print("Alright then.")
        else:
            print("I didn't understand that, could you please try again.")
print(f"Since we finished I will fully tell your states out of the {numRou} rounds.")
print(f"You have won {numWins} times, and you had lost {numLose} times. We also tied {numTies} times")
print(f"These are how many times you rolled each number, {numCop}")
print("I had a lot fun today friend, and I hope we can see each other again.")
print("Goodbye Friend!")
Goodbye = input(":")