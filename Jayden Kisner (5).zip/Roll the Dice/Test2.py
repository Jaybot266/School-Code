#Jayden Kisner
#9/6/22
#Roll the Dice = Test for main
import random as rd
myDict = {"Win": 0, "Lose": 0}
numRoll = {"One": 0, "Two": 0, "Three": 0, "Four": 0, "Five": 0, "Six": 0}
running = True
while running:
    perCho = input("Do you want to play?(y/n): ").upper()
    if perCho == "Y":
        comNum = rd.randint(1, 6)
        myNum = rd.randint(1, 6)
        print("...")
        print(comNum, myNum)
        if comNum < myNum:
            print("Win")
            myDict["Win"]+=1
            print(myDict)
            if myNum == 1:
                numRoll["One"]+=1
            else:
                if myNum == 2:
                    numRoll["Two"]+=1
                else:
                    if myNum == 3:
                        numRoll["Three"]+=1
                    else:
                        if myNum == 4:
                            numRoll["Four"]+=1
                        else:
                            if myNum == 5:
                                numRoll["Five"]+=1
                            else:
                                if myNum == 6:
                                    numRoll["Six"]+=1
        else:
            if comNum > myNum:
                print("Lose")
                myDict["Lose"]+=1
                print(myDict)
                if myNum == 1:
                    numRoll["One"] += 1
                else:
                    if myNum == 2:
                        numRoll["Two"] += 1
                    else:
                        if myNum == 3:
                            numRoll["Three"] += 1
                        else:
                            if myNum == 4:
                                numRoll["Four"] += 1
                            else:
                                if myNum == 5:
                                    numRoll["Five"] += 1
                                else:
                                    if myNum == 6:
                                        numRoll["Six"] += 1
            else:
                if comNum == myNum:
                    print("Tie")
                    print(myDict)
                    if myNum == 1:
                        numRoll["One"] += 1
                    else:
                        if myNum == 2:
                            numRoll["Two"] += 1
                        else:
                            if myNum == 3:
                                numRoll["Three"] += 1
                            else:
                                if myNum == 4:
                                    numRoll["Four"] += 1
                                else:
                                    if myNum == 5:
                                        numRoll["Five"] += 1
                                    else:
                                        if myNum == 6:
                                            numRoll["Six"] += 1
        print(numRoll)
    else:
        if perCho == "N":
            running = False