#Jayden Kisner
#11/31/22
#FoodServer = Using OOP to simulate a resturant by getting random orders or request from tables

import random as rd

class Waiter():
    def __init__(self, tables):
        self.table = tables

    def work(self):
        return self.table

    def today(self):
        print(f'"I have to wait {self.table} tables today"')



class Table():
    def __init__(self, food, drink):
        self.food = food
        self.drink = drink

    def request(self):
        print(f'"I would like {self.food} to eat and a {self.drink} to drink please."')

    def order(self):
        oInfo = f"At table {tableNum}, they ordered {self.food}, and a {self.drink}."
        return oInfo

    def total(self):
        print(f"At table {tableNum} they had a total of {total} request")


waiting = Waiter(rd.randint(1,10))

#Here's a story about a girl named Tori
print("Tori wake's up on a Monday moring, and starts to get ready for work.")
print("Tori works at a steak house and hope's to one day be a fasion designer, though she has to work here to pay taxes.")
print("Then again she doesn't want to go to work, but she knows that she needs to.")
print('"I have to go to work evn though I do not feel like it because I need to pay these taxes."')
print("She arrives at her job, and clocks in.")
print("She then looks out and sees how many tables she need to do.")
waiting.today()
print(f"She thinks to her self")

totalReq = []
total = 0
Request = []
tableNum = 0
Foods = ['Sirloen steak', 'French Fries', 'Mac and Cheese', 'Cheeseburger', 'potato soup', 'NY strip', 'Ribeye',
         'Fried Chicken', 'Brocali', 'Filet mignon', 'Ceaser Salad', 'Lobster', 'Ribs', 'Glazed chicken',
         'A T-Bone steak', 'Rolls', 'Nothing']
Drinks = ['Water', 'Coke a cola', 'Root Beer', 'Mr.Pibb', 'Sprite', 'Dr.Pepper', 'Sweet Tea', 'UnSweet Tea', 'Coffee',
          'Diet Coke a cola', 'Milk', 'Apple juice', 'Beer', 'Nothing']

useCho = input ("Do you want to continue the story? (Y/N): ").upper

if useCho == 'Y':
    print("Let's continue.")
else:
    if useCho == 'N':
        print("Well there isn't much left to the story, so too bad.")

for i in range(waiting.work()):
    tableNum += 1
    treqUest = rd.randint(1, 5)
    print(f'"I am going to get the orders from table {tableNum}"')
    numRequest = 0
    total = 0
    for i in range(treqUest):
        table = Table(rd.choice(Foods), rd.choice(Drinks))
        table.request()
        Request.append(table.order())
        numRequest += 1
        total += 1
        if numRequest == treqUest:
            print("...")
            print('"We will take the bill please." and they leave the resturant.')
            totalReq.append(table.total())

Bill = (' '.join(Request))
print(Bill)
print("After a long day at work Tori heads home to get some sleep.")
