# Jayden Kisner
# 9/13/22
# Bad calculator: Using try/except statements and def statements to make a calculator.

SuccessandErrorcounter = {"Successful transactions": 0, "Error transactions": 0}
Plays = 0
#I don't fully know how to check for a valid operator
op = ['*', '+', '-', '/']
def update_SandE(key):
    SuccessandErrorcounter[key] += 1
    return


def calculate():
    if perOp == '*':
        return perNum1 * perNum2
    if perOp == '+':
        return perNum1 + perNum2
    if perOp == '-':
        return perNum1 - perNum2
    if perOp == '/':
        return perNum1 / perNum2


hello = input("Hello Friend, how are you?: ")
print("Well that's interesting to hear friend.")
print("Hey, I just installed a calculator onto my hard drive and I was wondering if you would like to try it?")
print("Oh, just to let you now I can only add, subtract, multiply, and divide at the moment.")
print("I will also let you how many successful inputs you put in and how many times it didn't work")
running = True
perPlay = input("Knowing what I told you, would you like to test it? (Y/N): ").upper()
if perPlay == 'Y':
    Plays += 1
    while running:
        num1 = input("Please enter your first number: ")
        num2 = input("Now enter your second number: ")
        perOp = input("Please chose an action (+,-,*,/): ")
        try:
            perNum1 = int(num1)
            perNum2 = int(num2)
            update_SandE("Successful transactions")
            print("...")
            print(f"Your answer is {calculate()}")
        except Exception as e:
            print("It appears something went wrong.")
            print(f"Your error was: {e}")
            update_SandE("Error transactions")
        theQue = input("Would you like to try again? (Y/N):").upper()
        if theQue == "N":
            print("Alight we'll stop.")
            running = False
            susCount = SuccessandErrorcounter["Successful transactions"]
            errCount = SuccessandErrorcounter["Error transactions"]
if Plays > 0:
    print("Its good to see that the calculator works")
    print(f"In the end you manage to have {susCount} successful operation, and only {errCount} times something went bad.")
else:
    print("That's alright maybe another time.")
print("Well friend I going to shut down now.")
print("Goodbye friend.")
goodbye = input(":")