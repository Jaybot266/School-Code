#Jayden Kisner
#8/30/22
#Crazy Socks - Making a list and using a loop to make crazy socks

import random as rd

print("Hello friend!")
print("Hey I got a magical drawer here, and its says that it contains an infinite amount of socks.")
print("After seeing that I though how many sock would it take me to to make a pair.")
print("Don't worry I'm not going to tell you all the socks I pull out. I will let you know when I got a pair.")
colors = ["Red", "Green", "Blue", "Indego", "Violet", "Orange", "Yellow", "Pink", "White", "Black", "Brown", "Gray",
          "Teal", "Lime", "Silver"]
shapes = ["squares", "circles", "rectangles", "pyramids", "triangles", "rhombuses", "stars", "hearts", "fishes", "rings"
    , "Ovals", "Pentagons", "Octagons", "crescents"]
#Both the randoms do work on one variable.
comPick = rd.choice(colors), \
          rd.choice(shapes)
Pairs = 0
running = True
ready = input("Are you ready to begin?(yes/no): ").upper()
if ready == "YES":
    print("Alright lets begin!")
else:
    if ready == "NO":
        print("Too late im already starting.")
    else:
        print("Sorry I didn't catch that I was too occupied with taking socks out.")
print("...")
while running:
    Pairs += 1
    perGuess = rd.choice(colors), \
               rd.choice(shapes)
    if perGuess == comPick:
        running = False
        print(f"I got a {comPick} sock.")
        print(f"I also got another {perGuess} sock.")
        print(f"It took {Pairs} pairs to find a match")
if Pairs > 100:
    print("That was a lot socks")
print("There are still a large number of socks in here.")
print(f"Though looking through {Pairs} pairs of socks has tired me out.")
print("I'm going to go lay down.")
print("Goodbye friend.")
goodbye = input(":")