import random as rd

colors = ["red", "green", "blue", "indego", "violet", "orange", "yellow", "pink", "white", "black"]
shapes = ["squares", "circles", "rectangle", "pyramid", "trangle", "rombus", "star", "heart", "fish", ]
print(colors)
print(shapes)
choice = input("ready?: ")
comcolor = rd.choice(colors).upper()
comShape = rd.choice(shapes).upper()
Pairs = 0
running = True
while running:
    Pairs += 1
    perGuess = rd.choice(colors).upper()
    PerGuess = rd.choice(shapes).upper()
    if perGuess == comcolor:
        running = False
        print(comcolor, comShape)
        print(perGuess, PerGuess)
        print(f" it took {Pairs} pairs to find a match")
        print("nice")
    else:
        if Pairs > 100:
            print(perGuess)
            print("nope")
            print(Pairs)
print("Yeet")