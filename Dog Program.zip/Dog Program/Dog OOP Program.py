#Jayden Kisner
#10/26/22
#Dog OOP Program - Modifying the program to add more function to the program, to get use to OPP programing.
import random as rd
class Dog():
    def __init__(self, name, color, age):
        self.name = name
        self.color = color
        self.age = age
        moodList = ["Happy", "Angry", "Sad", "Excited", "Hungry"]
        self.temperment = rd.choice(moodList)

    def getMood(self):
        return self.temperment

    def speak(self):
        print(f"{self.name} the {self.age} year old {self.color} dog says Woof Woof and is {self.temperment}")

    def isSitting(self):
        isSitting = rd.choice([True,False])
        if isSitting:
            print("         yes, I am sitting")
        else:
            print("         no, I am not sitting")

    def getDogInfo(self):
        dInfo = f"{self.name} is {self.color} and {self.age} years old."
        return dInfo

    def DogAges(self):
        return self.age





nameList = ["Bob", "Kenda", "Maddy", "Sam", "Jay", "Jayden", "Gavin", "Storm", "Cedar", "Ian", "Evelyn", "Wyatt", "Trenton"]
colorList = ["Brown", "Yellow", "Grey", "Black", "White", "Tan", "Red", "Orange"]
dogList = []
dogAge = []
for i in range(50):
    dog = Dog(rd.choice(nameList), rd.choice(colorList), rd.randint(1,14))
    dog.speak()
    dog.isSitting()
    dogList.append(dog.getDogInfo())
    dogAge.append(dog.DogAges())

Average = sum(dogAge) // 50

print(dogList)
print(f"The average age is {Average} years old.")
