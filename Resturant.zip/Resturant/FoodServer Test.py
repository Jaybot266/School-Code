#Jayden Kisner
#10/31/22
#This is a test for Foodserver program

import random as rd

class Waitress():
    def __init__(self, tables):
        self.table = tables

    def work(self):
        return self.table

    def today(self):
        print(f'"I have to wait {self.table} tables today"')

class Table():
    def __init__(self, food, drink):
        self.food = food
        self.drink = drink

    def request(self):
        print(f'"I would like {self.food} to eat and a {self.drink} to drink please."')

    def order(self):
        oInfo = f"At table {tableNum}, they ordered {self.food}, and a {self.drink}"
        return oInfo


waiting = Waitress(rd.randint(1,10))
waiting.today()
Request = []
tableNum = 0
Foods = ['Sirloen steak', 'French Fries', 'Mac and Cheese', 'Cheeseburger', 'potato soup', 'NY strip', 'Ribeye',
         'Fried Chicken', 'Brocali', 'Filet mignon', 'Ceaser Salad', 'Lobster', 'Ribs', 'Glazed chicken',
         'A T-Bone steak', 'Rolls', 'Nothing']
Drinks = ['Water', 'Coke a cola', 'Root Beer', 'Mr.Pibb', 'Sprite', 'Dr.Pepper', 'Sweet Tea', 'UnSweet Tea', 'Coffee',
          'Diet Coke a cola', 'Milk', 'Apple juice', 'Beer', 'Nothing']


for i in range(waiting.work()):
    tableNum += 1
    tabreq = rd.randint(1, 5)
    print(f"I am going to get the orders from table {tableNum}")
    print("Welcome to Steve's gril, what would you like?")
    numRequest = 0
    for i in range(tabreq):
        table = Table(rd.choice(Foods), rd.choice(Drinks))
        table.request()
        Request.append(table.order())
        numRequest += 1
        if numRequest == tabreq:
            print('"We will take the bill please."')



print(Request)
print("That's all the tables, I'm heading home.")
