running = True
def nodupes(string):
    newstring = ''
    for i in string:
        if i not in newstring:
            newstring += i
    return newstring



def buildcypherdict(CypherString,PlainString):
    cypherdict =  {}
    clen = len(CypherString)
    for i in range(0, clen -1):
        cypherdict[PlainString[i]] = CypherString[i]
    return cypherdict


def buildDecypherdict(PlainString,CypherString):
    Decypherdict =  {}
    clen = len(CypherString)
    for i in range(0, clen -1):
        Decypherdict[CypherString[i]] = PlainString[i]
    return Decypherdict


def changemsg(message,dictonary):
    newMsg = ''
    for i in range(0, len(message)):
        value = dictonary.get(message[i], "Empty")
        if value == "Empty":
            newMsg += message[i]
        else:
            newMsg += value
    return newMsg

print("Hola Amigo, my creater has given me an update.")
print("All you have to do is write down in a file what you want to say and then tell me to encrypt or decrypt it.")
print("To help you the EncryptFile is what will be encrypted, and the DecryptedFile is what will be decrypted.")
print("Like the last I will require a key to encrypt it and decrypt it.")
print("So lets test this out.")

keyword = input("Please enter a key that is at least 3 letters long and with minial special characters and numbers: ")
while (len(keyword) < 3):
    keyword = input("That doesn't seem long enough. Try to make it longer: ")
    keyword = nodupes(keyword)


PlainString = ('abcdefghijklmnopqrstuvwxyzABCEDFGHIJKLMNOPQRSTUVWXYZ0123456789.,-/?!$% ')
CypherString = (nodupes(keyword +'zyxwvutsrqponmlkjihgfedcbaZYXWVUTSRQPONMLKJIHGFEDCBA9876543210%$!?/-,. '))

UsetoEncrypt = buildcypherdict(CypherString, PlainString)
UsetoDecrypt = buildDecypherdict(PlainString,CypherString)
useCho = input("Would you like to Encrypt or Decrypt \n")

while running:
    if (useCho.upper() == "ENCRYPT"):
        EnFile = open("EncryptFile.txt","r")
        TwoFile = open("DecryptFile.txt", "a")
        Lines = EnFile.readlines()
        for Line in Lines:
            NewLine = changemsg(Line, UsetoEncrypt)
            TwoFile.write(NewLine)
        EnFile.close()
        TwoFile.close()
        print(f"Your message has been encrypted")
        running = False
    else:
        if (useCho.upper() == "DECRYPT"):
            EnFile = open("EncryptFile.txt", "a")
            TwoFile = open("DecryptFile.txt", "r")
            Lines = TwoFile.readlines()
            for Line in Lines:
                NewLine = changemsg(Line, UsetoDecrypt)
                EnFile.write(NewLine)
            EnFile.close()
            TwoFile.close()
            print(f"Your encrypted message has been decrypted")
            running = False
        else:
            if useCho != 'ENCRYPT' or 'DECRYPT':
                print("That is an option, please try again. \n")
                useCho = input("Encrypt or Decrypt \n")
print("That was pretty easy, wouldn't you say Amigo.")
print("I would recommend that you delete your message that is not encrypted so no one knows what you were trying to say.")
print("I don't have much more time, so goodbye Amigo.")
goodbye = input(":")