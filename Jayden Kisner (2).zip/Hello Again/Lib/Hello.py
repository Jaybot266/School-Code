#Jayden Kisner
#08/25/22
#Hello - making a string of code

print("Hello again. How are you.")
name = input("Oh silly me I forgot to ask you about your name. What is your name? :")
if name == "Barney":
    print("How are you buddy")
else:
    print("Its nice to know your name")