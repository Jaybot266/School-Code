#Just wrote down the loopy.txt for easier observation.
import random as rd

tlNum = input("Please enter your desired loopcount")
dLoopCount = int(tlNum)
loopCount = 0
running = True
while running:
    myNum = rd.randint(1,30)
    targetNum = rd.randint(1,30)

    loopCount += 1
    if targetNum == myNum or loopCount > dLoopCount:
        running = False
        print(f"Hey, your loopCount was: {loopCount}")
        print(myNum)
        print(targetNum)