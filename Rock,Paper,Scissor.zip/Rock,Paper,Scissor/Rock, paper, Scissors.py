#Jayden Kisner
#4/4/23
#Rock,Paper,Scissors - Player choses between the 3 and the computer randomly choses and then campre the results to see who won
import random as rd

running = True

comPick = ("R", "P", "S")
myDict = {"Wins": 0, "Loses": 0, "Ties":0}
pRound = 0

print("Hello amigo, its me again and I've came up with a new game for us to play.")
print("That game is Rock, Paper, Scissors.")
pKnow = input("Do you know that game? (Y/N):").upper()
if pKnow == "N":
    print("In this game you chose between the 3 options and try to beat me.")
    print("In the game Rock beats Scissors, Scissors beats Paper, and Paper beats Rock")
else:
    print("I figured you did")
print("To make it easier just type R for rock, P for Paper, and S for scissors")


while running:
    pPlay = input("Would you like to play? (Y/N): ").upper()
    if pPlay == "Y":
        comCho = rd.choice(comPick)
        pPick = input("Plese enter your choice between R, P, or S: ").upper()

        if comCho == "P":
            comDec = "Paper"
        else:
            if comCho == "R":
                comDec = "Rock"
            else:
                if comCho == "S":
                    comDec = "Scissors"

        if pPick == "P":
            pDec = "Paper"
        else:
            if pPick == "R":
                pDec = "Rock"
            else:
                if pPick == "S":
                    pDec = "Scissors"

        print(f"You pick {pDec} and the computer picked {comDec}")
        if pPick == "R" and comCho == "S":
            print("You win")
            myDict["Wins"] += 1
        else:
            if pPick == "P" and comCho == "R":
                print("You win")
                myDict["Wins"] += 1
            else:
                if pPick == "S" and comCho == "P":
                    print("You win")
                    myDict["Wins"] += 1
                else:
                    if pPick == "R" and comCho == "R":
                        print("You Tied")
                        myDict["Ties"] += 1
                    else:
                        if pPick == "P" and comCho == "P":
                            print("You Tied")
                            myDict["Ties"] += 1
                        else:
                            if pPick == "S" and comCho == "S":
                                print("You Tied")
                                myDict["Ties"] += 1
                            else:
                                print("You Lose")
                                myDict["Loses"] += 1

        print(myDict)
        pRound += 1
    if pPlay == "N":
        numWins = myDict.get("Wins")
        numLose = myDict.get("Loses")
        numTies = myDict.get("Ties")
        running = False
    else:
        print("That doesn't answer my question.")

if pRound == 0:
    print("Thats asame I was hoping to play with you.")
else:
    print(f"That was fun, and we played {pRound} rounds")
print("I kept track of the states of the entire game")
print(f"You had won {numWins} times, and you had lost {numLose} times. We also tied {numTies} times")
print("I'll see you around my friend")

