#Jayden Kisner
#9/27/22
#List of List Test
import random as rd

InList = ["Pasta", "Strawberrys", "Avacados", "Ground Beef", "Oranges", "Pepper", "Salt", "Pork", "Bread", "Lettece", "Ginger", "Basil", "apples", "Eggs", "Carrots", "Butter", "Potatos", "Bacon", "Tomatos", "Paprika", "Squids", "Crabs", "Onions", "Chocolate", "Spagethei sauce", "oysters", "Milk", "Pears", "Fish", "Dill", "Spinage", "Chicken", "Chips", "Shrimp"]

Shopping = True

loop = 0

UseChoice = input("How many days do you want to go shopping: ")
UseChoice = int(UseChoice)
ItemsGot = []
for i in range(UseChoice):
    for i in range(5):
        try:
            Steve = rd.choice(InList)
            ItemsGot.append(Steve)
        except:
            print(ItemsGot)
print(f"She got {ItemsGot} at the store today.")
goodbye = input(":")
