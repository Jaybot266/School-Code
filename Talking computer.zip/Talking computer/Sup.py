nice = "Bob"
print(" Hello there how are you")
print("How is the weather today. I hope its good")
print(f'Oh how rude of me i forgot to tell you my name. My name is {nice}')
print("It's nice to meet you and I hope that you meet my friends at some point")
print('I will say that I am friends with Barney')
print('Well I am going to grab a bite with them')
print('Goodbye')