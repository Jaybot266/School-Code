import sqlite3
from sqlite3 import Error

def insert_info(File_Type, Name, Tags):
    conn = sqlite3.connect('Gallery_Database.db')
    conn.execute("INSERT INTO GALLERY_DATABASE (FILE_TYPE, NAME, TAGS) \
        VALUES (?,?,?)", (File_Type, Name, Tags))
    conn.commit()
    conn.close()

def retreve_Into():
    results = []
    conn = sqlite3.connect('Gallery_Database.db')
    cursor = conn.execute("SELECT File_type, Name, Tags from GALLERY_DATABASE")
    for row in cursor:
        results.append(list(row))
    return results
