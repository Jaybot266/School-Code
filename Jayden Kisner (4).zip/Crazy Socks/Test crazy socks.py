#Jayden Kisner
#8/30/22
#Crazy Socks- test for now

import random as rd

colors = ["red", "green", "blue", "indego", "violet", "orange", "yellow", "pink", "white", "black"]
shapes = ["squares", "circles", "rectangle", "pyramid", "trangle", "rombus", "star", "heart", "fish", ]
print(colors)
print(shapes)
choice = input("ready?: ")
comPick = rd.choice(colors).upper(), rd.choice(shapes).upper()
Pairs = 0
running = True
while running:
    Pairs += 1
    perGuess = rd.choice(colors).upper(), rd.choice(shapes).upper()
    if perGuess == comPick:
        running = False
        print(comPick)
        print(perGuess)
        print(f" it took {Pairs} pairs to find a match")
if Pairs > 20:
    print("That's a few socks")
print("There are still a large number of socks in here.")