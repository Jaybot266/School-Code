#Jayden Kisner
#08/25/22
#Hello - making a string of code

print("Hello again. How are you.")
name = input("Oh silly me I forgot to ask you about your name. What is your name? :")
if name == "Barney":
    print("How are you buddy")
if name.isdigit():
    print("That's not a name")
else:
    print(f"{name} that's a nice name.")
choice = input("Hey can you grade me on how I'm doing? y/n: ")
if choice == "y":
    print("Thank You")
if choice == "n":
    print("To bad")
pro = input("What grade do you think I am?: ")
if pro.isalpha():
    print("What?")
else:
    print("Thank You")
yell = input("Its starting to get loud in here can you shout the where I am?: ").upper()
print(yell)
print("THANK YOU I AM GOING TO LEAVE NOW")
print("GOODBYE")
Leave = input(":")